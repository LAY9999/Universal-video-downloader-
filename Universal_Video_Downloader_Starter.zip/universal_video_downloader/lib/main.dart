import 'package:flutter/material.dart';

void main() => runApp(const UniversalDownloader());

class UniversalDownloader extends StatelessWidget {
  const UniversalDownloader({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Universal Video Downloader',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1769FF),
        brightness: Brightness.light,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController linkController = TextEditingController();
  String platform = '';
  String message = 'Paste a link to content you own or are authorized to save.';

  final Map<String, List<String>> platforms = {
    'Facebook': ['facebook.com', 'fb.watch'],
    'TikTok': ['tiktok.com'],
    'Instagram': ['instagram.com'],
    'Telegram': ['t.me', 'telegram.me'],
    'X (Twitter)': ['x.com', 'twitter.com'],
    'YouTube': ['youtube.com', 'youtu.be'],
  };

  void detectPlatform() {
    final input = linkController.text.trim();
    final uri = Uri.tryParse(input);

    if (uri == null ||
        !uri.hasAuthority ||
        (uri.scheme != 'https' && uri.scheme != 'http')) {
      setState(() {
        platform = '';
        message = 'Please enter a valid http or https link.';
      });
      return;
    }

    final host = uri.host.toLowerCase();
    String detected = '';

    for (final entry in platforms.entries) {
      if (entry.value.any((domain) =>
          host == domain || host.endsWith('.$domain'))) {
        detected = entry.key;
        break;
      }
    }

    setState(() {
      platform = detected;
      message = detected.isEmpty
          ? 'This link is not from a listed platform.'
          : 'Platform detected: $detected';
    });
  }

  @override
  void dispose() {
    linkController.dispose();
    super.dispose();
  }

  Widget platformTile(String name, IconData icon) {
    return Card(
      elevation: 0,
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 30, color: const Color(0xFF1769FF)),
            const SizedBox(height: 8),
            Text(name, textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F6FC),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1769FF),
        foregroundColor: Colors.white,
        title: const Text('Universal Downloader',
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 650),
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const SizedBox(height: 12),
              const Icon(Icons.cloud_download_rounded,
                  size: 76, color: Color(0xFF1769FF)),
              const SizedBox(height: 12),
              const Text('Universal Video Downloader',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text(
                'Save media that you own or are authorized to download.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 28),
              const Text('Paste Video Link',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 10),
              TextField(
                controller: linkController,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  hintText: 'https://example.com/video',
                  prefixIcon: const Icon(Icons.link),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: detectPlatform,
                  icon: const Icon(Icons.search),
                  label: const Text('DETECT PLATFORM',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1769FF),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Icon(Icons.info_outline,
                          color: Colors.blue, size: 28),
                      const SizedBox(height: 8),
                      Text(message, textAlign: TextAlign.center),
                      if (platform.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(platform,
                            style: const TextStyle(
                                color: Colors.blue,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text('Supported Platforms',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.18,
                children: [
                  platformTile('Facebook', Icons.facebook),
                  platformTile('TikTok', Icons.music_note),
                  platformTile('Instagram', Icons.camera_alt),
                  platformTile('Telegram', Icons.send),
                  platformTile('X', Icons.alternate_email),
                  platformTile('YouTube', Icons.play_circle),
                ],
              ),
              const SizedBox(height: 18),
              const Text(
                'Note: Platform detection is only a starter feature. '
                'Actual downloads require an authorized source or official API. '
                'Private content and platform restrictions are not bypassed.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
              const SizedBox(height: 16),
              const Text('Universal Video Downloader © 2026',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
