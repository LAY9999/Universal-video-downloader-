# Universal Video Downloader

Starter Flutter project for Android and Web builds using GitHub + Codemagic.

## Included
- Flutter home screen
- URL validation and platform-domain detection for Facebook, TikTok, Instagram, Telegram, X and YouTube
- Codemagic workflows for Android APK and Web

## Important
This starter only validates a URL and detects its domain. It does not download videos yet.
Actual media retrieval must use official/authorized APIs or user-provided media files and must respect copyright, privacy, and each platform's terms. It does not bypass private-content restrictions or DRM.

## Codemagic
1. Push this repository to GitHub.
2. Add the repository in Codemagic.
3. Select `codemagic.yaml` workflows.
4. Run `android-workflow` for APK or `web-workflow` for web output.
